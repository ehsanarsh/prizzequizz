import { randomUUID } from 'node:crypto';
export function id() { return randomUUID(); }
