import { ValidationError } from '../core/errors.js';
export function bodyObject(body) {
    if (!body || typeof body !== 'object' || Array.isArray(body))
        throw new ValidationError('Request body must be an object');
    return body;
}
export function requiredString(body, key) {
    const value = body[key];
    if (typeof value !== 'string' || !value.trim())
        throw new ValidationError(`${key} is required`, { key });
    return value.trim();
}
export function optionalString(body, key, fallback = '') {
    const value = body[key];
    return typeof value === 'string' ? value.trim() : fallback;
}
export function requiredNumber(body, key) {
    const value = Number(body[key]);
    if (!Number.isFinite(value))
        throw new ValidationError(`${key} must be a number`, { key });
    return value;
}
export function optionalNumber(body, key, fallback = 0) {
    const value = body[key] === undefined ? fallback : Number(body[key]);
    if (!Number.isFinite(value))
        throw new ValidationError(`${key} must be a number`, { key });
    return value;
}
export function requiredOptions(body, key = 'options') {
    const value = body[key];
    if (!Array.isArray(value) || value.length !== 4 || value.some((x) => typeof x !== 'string' || !x.trim())) {
        throw new ValidationError('Exactly four non-empty options are required', { key });
    }
    return value.map((x) => String(x).trim());
}
