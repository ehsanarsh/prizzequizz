import { db } from './memory.js';
export const memoryRepositories = {
    beta: {
        async saveInvite(invite) { db.betaInvites.set(invite.code.toUpperCase(), { ...invite, code: invite.code.toUpperCase() }); },
        async findInvite(code) { return db.betaInvites.get(code.toUpperCase()) ?? null; },
        async listInvites(limit = 100) { return [...db.betaInvites.values()].sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit); },
        async updateInviteStatus(code, status) { const invite = db.betaInvites.get(code.toUpperCase()); if (!invite)
            return null; invite.status = status; db.betaInvites.set(invite.code, invite); return invite; },
        async saveAccess(access) { db.betaAccess.set(access.userId, access); },
        async findAccess(userId) { return db.betaAccess.get(userId) ?? null; },
        async listAccess(limit = 100) { return [...db.betaAccess.values()].sort((a, b) => b.grantedAt.localeCompare(a.grantedAt)).slice(0, limit); }
    },
    characters: {
        async listItems(status) { return [...db.characterItems.values()].filter((item) => !status || item.status === status).sort((a, b) => a.slot.localeCompare(b.slot) || a.title.localeCompare(b.title)); },
        async findItemById(id) { return db.characterItems.get(id) ?? null; },
        async saveItem(item) { db.characterItems.set(item.id, item); },
        async updateItemStatus(id, status) { const item = db.characterItems.get(id); if (!item)
            return null; item.status = status; item.updatedAt = new Date().toISOString(); db.characterItems.set(id, item); return item; },
        async getInventory(userId) { return db.characterInventories.get(userId) ?? null; },
        async saveInventory(inventory) { db.characterInventories.set(inventory.userId, inventory); },
        async appendUnlockEvent(event) { db.characterUnlockEvents.set(event.id, event); },
        async listUnlockEvents(userId, limit = 100) { return [...db.characterUnlockEvents.values()].filter((e) => e.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit); }
    },
    users: {
        async findById(id) { return db.users.get(id) ?? null; },
        async findByPhone(phone) { return [...db.users.values()].find((u) => u.phone === phone) ?? null; },
        async list(limit = 1000) { return [...db.users.values()].slice(0, limit); },
        async save(user) { db.users.set(user.id, user); },
        async updateLifelines(userId, lifelines) { const u = db.users.get(userId); if (u) {
            u.lifelines = lifelines;
            db.users.set(userId, u);
        } }
    },
    questions: {
        async findById(id) { return db.questions.get(id) ?? null; },
        async listApproved() { return [...db.questions.values()].filter((q) => q.status === 'approved'); },
        async listAll(status) { return [...db.questions.values()].filter((q) => !status || q.status === status); },
        async save(question) { db.questions.set(question.id, question); },
        async remove(id) { db.questions.delete(id); }
    },
    matches: {
        async findById(id) { return db.matches.get(id) ?? null; },
        async save(match) { db.matches.set(match.id, match); }
    },
    answers: {
        async findByIdempotencyKey(key) { return [...db.answers.values()].find((a) => a.idempotencyKey === key) ?? null; },
        async listByMatch(matchId) { return [...db.answers.values()].filter((a) => a.matchId === matchId).sort((a, b) => a.createdAt.localeCompare(b.createdAt)); },
        async listByUser(userId, limit = 100) { return [...db.answers.values()].filter((a) => a.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit); },
        async save(answer) { db.answers.set(answer.id, answer); }
    },
    rewards: {
        async findByIdempotencyKey(key) { return [...db.rewards.values()].find((r) => r.idempotencyKey === key) ?? null; },
        async save(reward) { if (!reward.id)
            throw new Error('REWARD_ID_REQUIRED'); db.rewards.set(reward.id, reward); }
    },
    rewardHolds: {
        async save(hold) { db.rewardHolds.set(hold.id, hold); },
        async findById(id) { return db.rewardHolds.get(id) ?? null; },
        async findByIdempotencyKey(idempotencyKey) { return [...db.rewardHolds.values()].find((h) => h.idempotencyKey === idempotencyKey) ?? null; },
        async list(filter = {}) { const limit = Math.min(500, Math.max(1, Number(filter.limit ?? 100))); return [...db.rewardHolds.values()].filter((h) => !filter.userId || h.userId === filter.userId).filter((h) => !filter.matchId || h.matchId === filter.matchId).filter((h) => !filter.status || h.status === filter.status).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit); },
        async updateStatus(id, status, reviewedBy, extra = {}) { const hold = db.rewardHolds.get(id); if (!hold)
            return null; const now = new Date().toISOString(); Object.assign(hold, extra, { status, reviewedBy, reviewedAt: now }); db.rewardHolds.set(id, hold); return hold; }
    },
    support: {
        async saveTicket(ticket) { db.supportTickets.set(ticket.id, ticket); },
        async findTicketById(id) { return db.supportTickets.get(id) ?? null; },
        async listTickets(filter = {}) { const f = filter; const limit = Math.min(500, Math.max(1, Number(f.limit ?? 100))); return [...db.supportTickets.values()].filter((t) => !f.userId || t.userId === f.userId).filter((t) => !f.status || t.status === f.status).filter((t) => !f.category || t.category === f.category).filter((t) => !f.priority || t.priority === f.priority).filter((t) => !f.assignedAdminId || t.assignedAdminId === f.assignedAdminId).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)).slice(0, limit); },
        async updateTicket(id, patch) { const t = db.supportTickets.get(id); if (!t)
            return null; Object.assign(t, patch, { updatedAt: new Date().toISOString() }); db.supportTickets.set(id, t); return t; },
        async appendMessage(message) { db.supportMessages.set(message.id, message); },
        async listMessages(ticketId) { return [...db.supportMessages.values()].filter((m) => m.ticketId === ticketId).sort((a, b) => a.createdAt.localeCompare(b.createdAt)); }
    },
    transactions: {
        async findById(id) { return db.transactions.get(id) ?? null; },
        async list(filter = {}) {
            const f = filter;
            const limit = Math.min(1000, Math.max(1, Number(f.limit ?? 100)));
            return [...db.transactions.values()]
                .filter((t) => !f.userId || t.userId === f.userId)
                .filter((t) => !f.type || t.type === f.type)
                .filter((t) => !f.direction || t.direction === f.direction)
                .filter((t) => !f.status || t.status === f.status)
                .filter((t) => !f.currency || t.currency === f.currency)
                .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
                .slice(0, limit);
        },
        async listByUser(userId) { return [...db.transactions.values()].filter((t) => t.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)); },
        async listWinnings(limit = 100) {
            const totals = new Map();
            for (const t of db.transactions.values()) {
                if (t.direction !== 'in' || t.status === 'failed')
                    continue;
                if (!['reward', 'win'].includes(t.type))
                    continue;
                if (!['cash', 'coins'].includes(t.currency))
                    continue;
                totals.set(t.userId, (totals.get(t.userId) ?? 0) + Number(t.amount));
            }
            return [...totals.entries()].map(([userId, score]) => ({ userId, score })).sort((a, b) => b.score - a.score).slice(0, limit);
        },
        async listWeeklyWinnings(limit = 100) {
            // Monday 00:00 of the current week — the same boundary the cup resets on.
            const now = new Date();
            const day = (now.getUTCDay() + 6) % 7; // Mon=0 … Sun=6
            const weekStart = Date.UTC(now.getUTCFullYear(), now.getUTCMonth(), now.getUTCDate() - day);
            const totals = new Map();
            for (const t of db.transactions.values()) {
                if (t.direction !== 'in' || t.status === 'failed')
                    continue;
                if (!['reward', 'win'].includes(t.type))
                    continue;
                if (!['cash', 'coins'].includes(t.currency))
                    continue;
                if (new Date(t.createdAt).getTime() < weekStart)
                    continue;
                totals.set(t.userId, (totals.get(t.userId) ?? 0) + Number(t.amount));
            }
            return [...totals.entries()].map(([userId, score]) => ({ userId, score })).sort((a, b) => b.score - a.score).slice(0, limit);
        },
        async save(transaction) { db.transactions.set(transaction.id, transaction); },
        async updateStatus(id, status, reference) { const txn = db.transactions.get(id); if (!txn)
            return null; txn.status = status; if (reference)
            txn.reference = reference; db.transactions.set(id, txn); return txn; }
    },
    matchEvents: {
        async append(event) { db.matchEvents.set(event.id, event); },
        async listByMatch(matchId) { return [...db.matchEvents.values()].filter((e) => e.matchId === matchId).sort((a, b) => a.createdAt.localeCompare(b.createdAt)); }
    },
    devices: {
        async findById(id) { return db.devices.get(id) ?? null; },
        async findByFingerprintHash(fingerprintHash) { return [...db.devices.values()].find((d) => d.fingerprintHash === fingerprintHash) ?? null; },
        async saveDevice(device) { db.devices.set(device.id, device); },
        async listDevices(limit = 500) { return [...db.devices.values()].sort((a, b) => b.lastSeenAt.localeCompare(a.lastSeenAt)).slice(0, limit); },
        async findBinding(userId, deviceId) { return [...db.userDeviceBindings.values()].find((b) => b.userId === userId && b.deviceId === deviceId) ?? null; },
        async saveBinding(binding) { db.userDeviceBindings.set(binding.id, binding); },
        async listBindingsByUser(userId) { return [...db.userDeviceBindings.values()].filter((b) => b.userId === userId).sort((a, b) => b.lastSeenAt.localeCompare(a.lastSeenAt)); },
        async listBindingsByDevice(deviceId) { return [...db.userDeviceBindings.values()].filter((b) => b.deviceId === deviceId).sort((a, b) => b.lastSeenAt.localeCompare(a.lastSeenAt)); },
        async updateBindingStatus(bindingId, status) { const b = db.userDeviceBindings.get(bindingId); if (!b)
            return null; b.trustStatus = status; b.lastSeenAt = new Date().toISOString(); db.userDeviceBindings.set(bindingId, b); return b; },
        async getRiskProfile(userId) { return db.userRiskProfiles.get(userId) ?? null; },
        async saveRiskProfile(profile) { db.userRiskProfiles.set(profile.userId, profile); },
        async listRiskProfiles(limit = 100) { return [...db.userRiskProfiles.values()].sort((a, b) => b.riskScore - a.riskScore || b.updatedAt.localeCompare(a.updatedAt)).slice(0, limit); }
    },
    integrity: {
        async save(signal) { db.integritySignals.set(signal.id, signal); },
        async list(filter = {}) {
            const limit = Math.min(500, Math.max(1, Number(filter.limit ?? 100)));
            return [...db.integritySignals.values()]
                .filter((s) => !filter.userId || s.userId === filter.userId)
                .filter((s) => !filter.matchId || s.matchId === filter.matchId)
                .filter((s) => !filter.status || s.status === filter.status)
                .filter((s) => !filter.severity || s.severity === filter.severity)
                .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
                .slice(0, limit);
        },
        async findById(id) { return db.integritySignals.get(id) ?? null; },
        async updateStatus(id, status, reviewedBy) { const signal = db.integritySignals.get(id); if (!signal)
            return null; signal.status = status; signal.reviewedBy = reviewedBy; signal.reviewedAt = new Date().toISOString(); db.integritySignals.set(id, signal); return signal; }
    },
    errorReports: {
        async save(report) { db.errorReports.set(report.id, report); },
        async findById(id) { return db.errorReports.get(id) ?? null; },
        async list(filter = {}) { const f = filter; const limit = Math.min(500, Math.max(1, Number(f.limit ?? 100))); return [...db.errorReports.values()].filter((r) => !f.userId || r.userId === f.userId).filter((r) => !f.status || r.status === f.status).filter((r) => !f.source || r.source === f.source).filter((r) => !f.severity || r.severity === f.severity).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit); },
        async updateStatus(id, status, resolvedBy) { const report = db.errorReports.get(id); if (!report)
            return null; report.status = status; if (status === 'resolved' || status === 'ignored') {
            report.resolvedAt = new Date().toISOString();
            report.resolvedBy = resolvedBy;
        } db.errorReports.set(id, report); return report; }
    },
    payments: {
        async save(intent) { db.paymentIntents.set(intent.id, intent); },
        async findById(id) { return db.paymentIntents.get(id) ?? null; },
        async findByIdempotencyKey(key) { return [...db.paymentIntents.values()].find((i) => i.idempotencyKey === key) ?? null; },
        async list(filter = {}) { const f = filter; const limit = Math.min(500, Math.max(1, Number(f.limit ?? 100))); return [...db.paymentIntents.values()].filter((i) => !f.userId || i.userId === f.userId).filter((i) => !f.status || i.status === f.status).filter((i) => !f.provider || i.provider === f.provider).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit); },
        async updateStatus(id, status, patch = {}) { const intent = db.paymentIntents.get(id); if (!intent)
            return null; Object.assign(intent, patch, { status, updatedAt: new Date().toISOString() }); db.paymentIntents.set(id, intent); return intent; }
    },
    notifications: {
        async listSubscriptions(userId) { return [...db.pushSubscriptions.values()].filter((s) => s.userId === userId && !s.revokedAt).sort((a, b) => b.updatedAt.localeCompare(a.updatedAt)); },
        async saveSubscription(subscription) { db.pushSubscriptions.set(subscription.id, subscription); },
        async revokeSubscription(subscriptionId, userId) { const item = db.pushSubscriptions.get(subscriptionId); if (!item || item.userId !== userId || item.revokedAt)
            return false; item.revokedAt = new Date().toISOString(); item.updatedAt = item.revokedAt; db.pushSubscriptions.set(item.id, item); return true; },
        async getPreferences(userId) { return db.notificationPreferences.get(userId) ?? null; },
        async savePreferences(preferences) { db.notificationPreferences.set(preferences.userId, preferences); },
        async listNotifications(userId, limit = 50) { return [...db.notifications.values()].filter((n) => n.userId === userId).sort((a, b) => b.createdAt.localeCompare(a.createdAt)).slice(0, limit); },
        async saveNotification(notification) { db.notifications.set(notification.id, notification); },
        async markRead(notificationId, userId) { const n = db.notifications.get(notificationId); if (!n || n.userId !== userId)
            return false; n.readAt = n.readAt ?? new Date().toISOString(); n.status = 'read'; db.notifications.set(n.id, n); return true; },
        async markAllRead(userId) { let count = 0; for (const n of db.notifications.values()) {
            if (n.userId === userId && !n.readAt) {
                n.readAt = new Date().toISOString();
                n.status = 'read';
                count++;
            }
        } return count; }
    }
};
