import { id } from '../utils/id.js';
export const db = {
    betaInvites: new Map(),
    betaAccess: new Map(),
    characterItems: new Map(),
    characterInventories: new Map(),
    characterUnlockEvents: new Map(),
    users: new Map(),
    matches: new Map(),
    questions: new Map(),
    transactions: new Map(),
    answers: new Map(),
    rewards: new Map(),
    rewardHolds: new Map(),
    supportTickets: new Map(),
    supportMessages: new Map(),
    matchEvents: new Map(),
    adminLogs: new Map(),
    securityEvents: new Map(),
    integritySignals: new Map(),
    errorReports: new Map(),
    devices: new Map(),
    userDeviceBindings: new Map(),
    userRiskProfiles: new Map(),
    paymentIntents: new Map(),
    pushSubscriptions: new Map(),
    notificationPreferences: new Map(),
    notifications: new Map()
};
export function seedMemory() {
    if (db.users.size)
        return;
    const user = { id: 'u1', phone: '+989120000000', username: 'Shahab_9865', displayName: 'شهاب', plan: 'free', level: 3, xp: 3400, weeklyScore: 820, wallet: 900000, coins: 350, hearts: 3, tickets: { bronze: 1, silver: 0, gold: 0 } };
    db.users.set(user.id, user);
    const user2 = { id: 'u2', phone: '+989130000000', username: 'RezaFast', displayName: 'رضا', plan: 'free', level: 4, xp: 4100, weeklyScore: 760, wallet: 500000, coins: 420, hearts: 4, tickets: { bronze: 1, silver: 0, gold: 0 } };
    db.users.set(user2.id, user2);
    const questions = [
        { id: 'q1', category: 'عمومی', difficulty: 'easy', text: 'یک هفته چند روز است؟', options: ['۵ روز', '۶ روز', '۷ روز', '۸ روز'], correctIndex: 2, tags: ['easy'], status: 'approved', version: 1 },
        { id: 'q2', category: 'جغرافیا', difficulty: 'easy', text: 'پایتخت فرانسه کدام است؟', options: ['رم', 'مادرید', 'پاریس', 'لندن'], correctIndex: 2, tags: ['geo'], status: 'approved', version: 1 },
        { id: 'q3', category: 'علوم', difficulty: 'easy', text: 'فرمول شیمیایی آب چیست؟', options: ['CO2', 'H2O', 'O2', 'NaCl'], correctIndex: 1, tags: ['science'], status: 'approved', version: 1 }
    ];
    questions.forEach((q) => db.questions.set(q.id, q));
    db.transactions.set('t1', { id: 't1', userId: user.id, type: 'seed', currency: 'coins', amount: 350, direction: 'in', status: 'ok', reference: id(), createdAt: new Date().toISOString() });
}
