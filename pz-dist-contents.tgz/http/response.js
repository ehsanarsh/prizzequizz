import { id } from '../utils/id.js';
export function json(res, status, data) {
    res.statusCode = status;
    res.setHeader('content-type', 'application/json; charset=utf-8');
    res.end(JSON.stringify({ ok: true, data, requestId: String(res.getHeader('x-request-id') ?? id()) }));
}
export function error(res, status, code, message, details) {
    res.statusCode = status;
    res.setHeader('content-type', 'application/json; charset=utf-8');
    res.end(JSON.stringify({ ok: false, error: { code, message, status, details }, requestId: String(res.getHeader('x-request-id') ?? id()) }));
}
