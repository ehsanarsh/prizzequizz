import { createClient } from 'redis';
import { logger } from '../services/logger.js';
export class MemoryRealtimePubSub {
    handlers = new Map();
    async publish(channel, message) {
        this.handlers.get(channel)?.forEach((handler) => handler(message));
    }
    async subscribe(channel, handler) {
        if (!this.handlers.has(channel))
            this.handlers.set(channel, new Set());
        this.handlers.get(channel).add(handler);
        return () => this.handlers.get(channel)?.delete(handler);
    }
}
export class RedisRealtimePubSub {
    url;
    pubClient = null;
    subClient = null;
    handlers = new Map();
    subscribedChannels = new Set();
    constructor(url = process.env.REDIS_URL ?? 'redis://localhost:6379') {
        this.url = url;
    }
    async publish(channel, message) {
        const client = await this.getPubClient();
        await client.publish(channel, JSON.stringify(message));
    }
    async subscribe(channel, handler) {
        if (!this.handlers.has(channel))
            this.handlers.set(channel, new Set());
        this.handlers.get(channel).add(handler);
        if (!this.subscribedChannels.has(channel)) {
            const client = await this.getSubClient();
            await client.subscribe(channel, (raw) => {
                const parsed = this.parse(raw, channel);
                if (!parsed)
                    return;
                this.handlers.get(channel)?.forEach((fn) => fn(parsed));
            });
            this.subscribedChannels.add(channel);
            logger.info('redis_realtime_subscribed', { channel });
        }
        return () => {
            this.handlers.get(channel)?.delete(handler);
            if (this.handlers.get(channel)?.size === 0) {
                void this.unsubscribe(channel);
            }
        };
    }
    async unsubscribe(channel) {
        if (!this.subClient || !this.subscribedChannels.has(channel))
            return;
        await this.subClient.unsubscribe(channel);
        this.subscribedChannels.delete(channel);
        this.handlers.delete(channel);
        logger.info('redis_realtime_unsubscribed', { channel });
    }
    async getPubClient() {
        if (!this.pubClient) {
            this.pubClient = createClient({ url: this.url });
            this.pubClient.on('error', (error) => logger.error('redis_pubsub_publish_error', { message: error.message }));
            await this.pubClient.connect();
            logger.info('redis_realtime_publisher_connected', { url: this.redactedUrl() });
        }
        return this.pubClient;
    }
    async getSubClient() {
        if (!this.subClient) {
            this.subClient = createClient({ url: this.url });
            this.subClient.on('error', (error) => logger.error('redis_pubsub_subscribe_error', { message: error.message }));
            await this.subClient.connect();
            logger.info('redis_realtime_subscriber_connected', { url: this.redactedUrl() });
        }
        return this.subClient;
    }
    parse(raw, channel) {
        try {
            return JSON.parse(raw);
        }
        catch (error) {
            logger.warn('redis_realtime_invalid_message', { channel, rawLength: raw.length });
            return null;
        }
    }
    redactedUrl() {
        try {
            const u = new URL(this.url);
            if (u.password)
                u.password = '***';
            return u.toString();
        }
        catch {
            return 'redis-url';
        }
    }
}
export const realtimePubSub = process.env.REDIS_URL && process.env.REALTIME_ADAPTER === 'redis'
    ? new RedisRealtimePubSub()
    : new MemoryRealtimePubSub();
