import { createClient } from 'redis';
import { logger } from '../services/logger.js';
export class MemoryRealtimePresenceStore {
    records = new Map();
    async join(matchId, clientId, userId) {
        const now = Date.now();
        this.records.set(clientId, { clientId, matchId, userId, updatedAt: now, lastSeenAt: new Date(now).toISOString() });
    }
    async leave(matchId, clientId) {
        this.records.delete(clientId);
    }
    async touch(matchId, clientId) {
        const record = this.records.get(clientId);
        if (!record)
            return;
        const now = Date.now();
        record.updatedAt = now;
        record.lastSeenAt = new Date(now).toISOString();
    }
    async list(matchId) {
        await this.cleanup();
        return [...this.records.values()].filter((r) => r.matchId === matchId).map(({ userId, lastSeenAt }) => ({ userId, lastSeenAt }));
    }
    async cleanup(ttlMs = 45_000) {
        const now = Date.now();
        let removed = 0;
        for (const [clientId, record] of this.records.entries()) {
            if (now - record.updatedAt > ttlMs) {
                this.records.delete(clientId);
                removed += 1;
            }
        }
        return removed;
    }
}
export class RedisRealtimePresenceStore {
    url;
    client = null;
    ttlSeconds = Number(process.env.REALTIME_PRESENCE_TTL_SECONDS ?? 45);
    constructor(url = process.env.REDIS_URL ?? 'redis://localhost:6379') {
        this.url = url;
    }
    async join(matchId, clientId, userId) {
        const client = await this.getClient();
        const key = this.clientKey(matchId, clientId);
        const now = new Date().toISOString();
        await client.multi()
            .sAdd(this.roomKey(matchId), clientId)
            .set(key, JSON.stringify({ userId, lastSeenAt: now }), { EX: this.ttlSeconds })
            .expire(this.roomKey(matchId), this.ttlSeconds + 10)
            .exec();
    }
    async leave(matchId, clientId) {
        const client = await this.getClient();
        await client.multi().sRem(this.roomKey(matchId), clientId).del(this.clientKey(matchId, clientId)).exec();
    }
    async touch(matchId, clientId) {
        const client = await this.getClient();
        const key = this.clientKey(matchId, clientId);
        const raw = await client.get(key);
        if (!raw)
            return;
        const parsed = JSON.parse(raw);
        parsed.lastSeenAt = new Date().toISOString();
        await client.set(key, JSON.stringify(parsed), { EX: this.ttlSeconds });
    }
    async list(matchId) {
        const client = await this.getClient();
        const ids = await client.sMembers(this.roomKey(matchId));
        if (!ids.length)
            return [];
        const keys = ids.map((clientId) => this.clientKey(matchId, clientId));
        const values = await client.mGet(keys);
        const stale = [];
        const users = [];
        values.forEach((raw, index) => {
            if (!raw) {
                stale.push(ids[index]);
                return;
            }
            try {
                users.push(JSON.parse(raw));
            }
            catch {
                stale.push(ids[index]);
            }
        });
        if (stale.length)
            await client.sRem(this.roomKey(matchId), stale);
        return users;
    }
    async cleanup() {
        // Redis key expiration performs cleanup. list() opportunistically removes stale ids.
        return 0;
    }
    async getClient() {
        if (!this.client) {
            this.client = createClient({ url: this.url });
            this.client.on('error', (error) => logger.error('redis_presence_error', { message: error.message }));
            await this.client.connect();
            logger.info('redis_presence_connected', { url: this.redactedUrl() });
        }
        return this.client;
    }
    roomKey(matchId) { return `presence:match:${matchId}:clients`; }
    clientKey(matchId, clientId) { return `presence:match:${matchId}:client:${clientId}`; }
    redactedUrl() { try {
        const u = new URL(this.url);
        if (u.password)
            u.password = '***';
        return u.toString();
    }
    catch {
        return 'redis-url';
    } }
}
export const realtimePresenceStore = process.env.REDIS_URL && process.env.REALTIME_ADAPTER === 'redis'
    ? new RedisRealtimePresenceStore()
    : new MemoryRealtimePresenceStore();
