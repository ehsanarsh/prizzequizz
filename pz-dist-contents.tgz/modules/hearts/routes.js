import { json } from '../../http/response.js';
import { getHearts } from '../../services/heartService.js';
export function registerHeartRoutes(router, base) {
    router.add('GET', `${base}/hearts`, async (ctx) => {
        json(ctx.res, 200, await getHearts(ctx.userId ?? 'u1'));
    });
}
