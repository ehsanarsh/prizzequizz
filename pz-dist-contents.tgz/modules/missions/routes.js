import { error, json } from '../../http/response.js';
import { MissionError, boardFor, claim, record, recordLogin, METRICS } from '../../services/missionService.js';
export function registerMissionRoutes(router, base) {
    router.add('GET', `${base}/missions`, async (ctx) => {
        const userId = ctx.userId ?? 'u1';
        /* Opening the app IS the login signal, and this is the request that proves
         * it: the home strip loads the board on every start. Recorded BEFORE the
         * board is built so today's streak is already in the numbers the player is
         * about to look at. Doing it at /auth/otp/verify instead would only ever
         * count the days someone typed an SMS code, not the days they played. */
        await recordLogin(userId);
        json(ctx.res, 200, await boardFor(userId));
    });
    router.add('POST', `${base}/missions/:id/claim`, async (ctx) => {
        try {
            json(ctx.res, 200, await claim(ctx.userId ?? 'u1', ctx.params.id));
        }
        catch (e) {
            if (e instanceof MissionError) {
                const status = e.code === 'MISSION_NOT_FOUND' ? 404 : e.code === 'ALREADY_CLAIMED' ? 409 : 422;
                return error(ctx.res, status, e.code, e.message);
            }
            throw e;
        }
    });
    /* Client-reported activity for the things only the client can see — opening
     * the shop, watching an ad. Anything with money or a score behind it is
     * reported by the server that already knows it happened, never from here. */
    const CLIENT_METRICS = new Set(['shopVisit', 'adWatched', 'login']);
    router.add('POST', `${base}/missions/event`, async (ctx) => {
        const b = (ctx.body ?? {});
        const metric = String(b.metric ?? '');
        if (!CLIENT_METRICS.has(metric)) {
            return error(ctx.res, 422, 'METRIC_NOT_CLIENT_REPORTABLE', 'این شاخص از سمت بازی گزارش نمی‌شود.');
        }
        if (metric === 'login')
            await recordLogin(ctx.userId ?? 'u1');
        else
            await record(ctx.userId ?? 'u1', metric, 1, String(b.scope ?? ''));
        json(ctx.res, 200, { ok: true });
    });
    router.add('GET', `${base}/missions/metrics`, async (ctx) => {
        json(ctx.res, 200, { metrics: METRICS });
    });
}
