import { error, json } from '../../http/response.js';
import { requireAdmin } from '../../services/adminGuard.js';
import { createErrorReport, errorReportDiagnostics, listErrorReports, updateErrorReportStatus } from '../../services/errorReportService.js';
import { getPublicConfig } from '../../services/configService.js';
import { getCategoryImage } from '../../services/categoryImageService.js';
import { bodyObject, optionalString, requiredString } from '../../utils/validation.js';
export function registerMonitoringRoutes(router, base) {
    // Public, non-sensitive economy config so the game client uses LIVE values
    // (rake %, ticket prices, wallet limits) without a redeploy.
    router.add('GET', `${base}/config/public`, async (ctx) => json(ctx.res, 200, await getPublicConfig()));
    /* Topic artwork. Served from its own endpoint rather than inlined in the
     * config so the config payload stays small: the config carries a URL with a
     * ?v= stamp, and this answers it once with a year-long cache. */
    router.add('GET', `${base}/categories/:name/image`, async (ctx) => {
        const img = await getCategoryImage(decodeURIComponent(ctx.params.name ?? ''));
        if (!img)
            return error(ctx.res, 404, 'CATEGORY_IMAGE_NOT_FOUND', 'تصویری برای این موضوع ثبت نشده.');
        const inm = ctx.req.headers['if-none-match'];
        if (inm && String(inm).replace(/"/g, '') === img.etag) {
            ctx.res.statusCode = 304;
            ctx.res.end();
            return;
        }
        ctx.res.statusCode = 200;
        ctx.res.setHeader('content-type', img.mime);
        ctx.res.setHeader('content-length', String(img.data.length));
        ctx.res.setHeader('etag', `"${img.etag}"`);
        ctx.res.setHeader('cache-control', 'public, max-age=31536000, immutable');
        ctx.res.end(img.data);
    });
    router.add('POST', `${base}/monitoring/reports`, async (ctx) => {
        const body = bodyObject(ctx.body);
        const report = await createErrorReport({
            userId: ctx.userId,
            source: (optionalString(body, 'source', 'frontend') ?? 'frontend'),
            severity: (optionalString(body, 'severity', 'error') ?? 'error'),
            message: requiredString(body, 'message'),
            stack: optionalString(body, 'stack'),
            route: optionalString(body, 'route'),
            userAgent: optionalString(body, 'userAgent', String(ctx.req.headers['user-agent'] ?? '')),
            appVersion: optionalString(body, 'appVersion'),
            buildId: optionalString(body, 'buildId'),
            deviceId: ctx.deviceId ?? optionalString(body, 'deviceId'),
            metadata: typeof body.metadata === 'object' && body.metadata ? body.metadata : {}
        });
        json(ctx.res, 201, report);
    });
    router.add('GET', `${base}/admin/monitoring/diagnostics`, async (ctx) => {
        if (!requireAdmin(ctx))
            return;
        json(ctx.res, 200, await errorReportDiagnostics());
    });
    router.add('GET', `${base}/admin/monitoring/reports`, async (ctx) => {
        if (!requireAdmin(ctx))
            return;
        json(ctx.res, 200, await listErrorReports({
            source: (ctx.query.get('source') || undefined),
            severity: (ctx.query.get('severity') || undefined),
            status: (ctx.query.get('status') || undefined),
            userId: ctx.query.get('userId') || undefined,
            limit: Number(ctx.query.get('limit') ?? 100)
        }));
    });
    router.add('PATCH', `${base}/admin/monitoring/reports/:id/status`, async (ctx) => {
        if (!requireAdmin(ctx))
            return;
        const status = String(ctx.body?.status ?? 'triaged');
        if (!['open', 'triaged', 'resolved', 'ignored'].includes(status))
            return error(ctx.res, 422, 'ERROR_REPORT_STATUS_INVALID', 'Invalid error report status.');
        const updated = await updateErrorReportStatus(ctx.params.id, status, ctx.userId ?? 'system');
        if (!updated)
            return error(ctx.res, 404, 'ERROR_REPORT_NOT_FOUND', 'Error report not found.');
        json(ctx.res, 200, updated);
    });
}
