import pg from 'pg';
const { Pool } = pg;
let pool = null;
export function getPgPool() {
    if (!process.env.DATABASE_URL)
        throw new Error('DATABASE_URL is required for PostgreSQL mode');
    pool ??= new Pool({
        connectionString: process.env.DATABASE_URL,
        max: Number(process.env.PG_POOL_MAX ?? 10),
        idleTimeoutMillis: Number(process.env.PG_IDLE_TIMEOUT_MS ?? 30_000),
        connectionTimeoutMillis: Number(process.env.PG_CONNECTION_TIMEOUT_MS ?? 5_000),
        application_name: process.env.PG_APP_NAME ?? 'prizzequizz-api'
    });
    return pool;
}
export async function closePgPool() {
    if (!pool)
        return;
    await pool.end();
    pool = null;
}
export function getPgPoolStats() {
    if (!pool)
        return null;
    return { total: pool.totalCount, idle: pool.idleCount, waiting: pool.waitingCount };
}
