import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import { appConfig } from '../core/config.js';
const accessSecret = process.env.JWT_ACCESS_SECRET || (appConfig.nodeEnv === 'production' ? '' : 'dev-access-secret');
const refreshSecret = process.env.JWT_REFRESH_SECRET || (appConfig.nodeEnv === 'production' ? '' : 'dev-refresh-secret');
if (appConfig.nodeEnv === 'production' && (!accessSecret || !refreshSecret)) {
    throw new Error('JWT secrets must be configured in production');
}
// Access token lifetime. Kept long (default 7 days) so a play session never
// expires mid-match and the WebSocket token stays valid; the client also
// silently refreshes on launch via the 30-day refresh token.
const ACCESS_TTL_SEC = Number(process.env.ACCESS_TOKEN_TTL_SEC ?? 7 * 24 * 60 * 60);
export function signAccessToken(userId, role = 'user') {
    return sign({ sub: userId, typ: 'access', role, iat: now(), exp: now() + ACCESS_TTL_SEC, jti: randomUUID() }, accessSecret);
}
export function signRefreshToken(userId, role = 'user') {
    return sign({ sub: userId, typ: 'refresh', role, iat: now(), exp: now() + 30 * 24 * 60 * 60, jti: randomUUID() }, refreshSecret);
}
export function verifyAccessToken(token) {
    const payload = verify(token, accessSecret);
    return payload?.typ === 'access' ? payload : null;
}
export function verifyRefreshToken(token) {
    const payload = verify(token, refreshSecret);
    return payload?.typ === 'refresh' ? payload : null;
}
function sign(payload, secret) {
    const header = { alg: 'HS256', typ: 'JWT' };
    const encodedHeader = b64(JSON.stringify(header));
    const encodedPayload = b64(JSON.stringify(payload));
    const signature = hmac(`${encodedHeader}.${encodedPayload}`, secret);
    return `${encodedHeader}.${encodedPayload}.${signature}`;
}
function verify(token, secret) {
    const parts = token.split('.');
    if (parts.length !== 3)
        return null;
    const [header, payload, sig] = parts;
    const expected = hmac(`${header}.${payload}`, secret);
    if (!safeEqual(sig, expected))
        return null;
    try {
        const parsed = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
        if (!parsed.exp || parsed.exp < now())
            return null;
        return parsed;
    }
    catch {
        return null;
    }
}
function hmac(input, secret) {
    return createHmac('sha256', secret).update(input).digest('base64url');
}
function safeEqual(a, b) {
    const ab = Buffer.from(a);
    const bb = Buffer.from(b);
    return ab.length === bb.length && timingSafeEqual(ab, bb);
}
function b64(input) {
    return Buffer.from(input).toString('base64url');
}
function now() {
    return Math.floor(Date.now() / 1000);
}
