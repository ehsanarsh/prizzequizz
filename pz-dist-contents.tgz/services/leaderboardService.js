import { createClient } from 'redis';
import { repositories } from '../repositories/index.js';
import { id } from '../utils/id.js';
import { logger } from './logger.js';
import { realtimePubSub } from '../realtime/pubSub.js';
class MemoryLeaderboardAdapter {
    name = 'memory';
    boards = {
        weekly: new Map(),
        overall: new Map(),
        winnings: new Map()
    };
    lastUpdatedAt;
    async top(kind, limit) {
        return [...this.boards[kind].entries()]
            .map(([userId, score]) => ({ userId, score }))
            .sort((a, b) => b.score - a.score || a.userId.localeCompare(b.userId))
            .slice(0, limit);
    }
    async setScore(kind, userId, score) {
        this.boards[kind].set(userId, score);
        this.lastUpdatedAt = new Date().toISOString();
    }
    async increment(kind, userId, amount) {
        const next = (this.boards[kind].get(userId) ?? 0) + amount;
        this.boards[kind].set(userId, next);
        this.lastUpdatedAt = new Date().toISOString();
        return next;
    }
    async diagnostics() {
        return {
            adapter: this.name,
            boardSizes: {
                weekly: this.boards.weekly.size,
                overall: this.boards.overall.size,
                winnings: this.boards.winnings.size
            },
            lastUpdatedAt: this.lastUpdatedAt
        };
    }
}
class RedisLeaderboardAdapter {
    url;
    name = 'redis';
    client = null;
    lastUpdatedAt;
    constructor(url = process.env.REDIS_URL ?? 'redis://localhost:6379') {
        this.url = url;
    }
    async top(kind, limit) {
        const client = await this.getClient();
        const raw = await client.sendCommand(['ZREVRANGE', this.key(kind), '0', String(Math.max(0, limit - 1)), 'WITHSCORES']);
        const rows = Array.isArray(raw) ? raw : [];
        const result = [];
        // Handle BOTH shapes: RESP2 flat [member, score, member, score, …] and RESP3
        // tuples [[member, score], …]. The old code assumed only the flat form, so
        // under RESP3 it stringified the whole [id, score] pair into the userId
        // (e.g. "a08b29…,191") — an invalid UUID that crashed the enrich lookup.
        if (rows.length && Array.isArray(rows[0])) {
            for (const pair of rows) {
                result.push({ userId: String(pair[0]), score: Number(pair[1] ?? 0) });
            }
        }
        else {
            for (let i = 0; i < rows.length; i += 2) {
                result.push({ userId: String(rows[i]), score: Number(rows[i + 1] ?? 0) });
            }
        }
        return result;
    }
    async setScore(kind, userId, score) {
        const client = await this.getClient();
        await client.sendCommand(['ZADD', this.key(kind), String(score), userId]);
        this.lastUpdatedAt = new Date().toISOString();
    }
    async increment(kind, userId, amount) {
        const client = await this.getClient();
        const next = await client.sendCommand(['ZINCRBY', this.key(kind), String(amount), userId]);
        this.lastUpdatedAt = new Date().toISOString();
        return Number(next);
    }
    async diagnostics() {
        const client = await this.getClient();
        const [weekly, overall, winnings] = await Promise.all([
            client.sendCommand(['ZCARD', this.key('weekly')]),
            client.sendCommand(['ZCARD', this.key('overall')]),
            client.sendCommand(['ZCARD', this.key('winnings')])
        ]);
        return {
            adapter: this.name,
            redisUrl: this.redactedUrl(),
            boardSizes: { weekly: Number(weekly), overall: Number(overall), winnings: Number(winnings) },
            lastUpdatedAt: this.lastUpdatedAt
        };
    }
    key(kind) {
        return `prizzequizz:leaderboard:${kind}`;
    }
    async getClient() {
        if (!this.client) {
            this.client = createClient({ url: this.url });
            this.client.on('error', (error) => logger.error('redis_leaderboard_error', { message: error.message }));
            await this.client.connect();
            logger.info('redis_leaderboard_connected', { url: this.redactedUrl() });
        }
        return this.client;
    }
    redactedUrl() {
        try {
            const u = new URL(this.url);
            if (u.password)
                u.password = '***';
            return u.toString();
        }
        catch {
            return 'redis-url';
        }
    }
}
export class LeaderboardService {
    adapter;
    constructor(adapter) {
        this.adapter = adapter;
    }
    async get(kind, limit = 50, viewerUserId) {
        const safeLimit = clampLimit(limit);
        // weekly (🏆cup) and overall (XP) are read STRAIGHT from the users table so the
        // board always reflects the real, current scores — the in-memory/redis adapter
        // is only a cache and could be stale/empty (which showed an empty leaderboard
        // even though users had real xp/cup). 'winnings' still uses the adapter/txns.
        let rows;
        if (kind === 'winnings') {
            rows = await this.safeAdapterTop(kind, safeLimit);
            if (!rows.length)
                rows = await this.deriveRows(kind, safeLimit);
        }
        else {
            rows = await this.deriveRows(kind, safeLimit);
        }
        const entries = await this.enrich(kind, rows, viewerUserId);
        return {
            kind,
            title: titleFor(kind),
            metricLabel: metricLabelFor(kind),
            generatedAt: new Date().toISOString(),
            entries
        };
    }
    async updateUser(user) {
        if (user.id.startsWith('bot_'))
            return;
        await Promise.all([
            this.safeSetScore('weekly', user.id, Number(user.weeklyScore ?? 0)),
            this.safeSetScore('overall', user.id, Number(user.xp ?? 0))
        ]);
        await Promise.all([this.publish('weekly'), this.publish('overall')]);
    }
    async recordReward(user, reward) {
        if (user.id.startsWith('bot_'))
            return;
        if (reward.amount <= 0 || !['cash', 'coins'].includes(reward.type))
            return;
        await this.safeIncrement('winnings', user.id, reward.amount);
        await this.publish('winnings');
    }
    async diagnostics() {
        try {
            return { ...(await this.adapter.diagnostics()), fallbackAvailable: true };
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'diagnostics failed';
            logger.warn('leaderboard_diagnostics_failed', { message });
            return { adapter: this.adapter.name, boardSizes: { weekly: 0, overall: 0, winnings: 0 }, fallbackAvailable: true };
        }
    }
    async publish(kind) {
        try {
            const leaderboard = await this.get(kind, 20);
            await realtimePubSub.publish(`topic:leaderboard:${kind}`, {
                id: id(),
                type: 'server:leaderboard_update',
                payload: { kind, leaderboard },
                createdAt: new Date().toISOString()
            });
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'publish failed';
            logger.warn('leaderboard_publish_failed', { kind, message });
        }
    }
    async safeAdapterTop(kind, limit) {
        try {
            return await this.adapter.top(kind, limit);
        }
        catch (error) {
            const message = error instanceof Error ? error.message : 'leaderboard adapter top failed';
            logger.warn('leaderboard_adapter_top_failed', { kind, message });
            return [];
        }
    }
    async safeSetScore(kind, userId, score) {
        try {
            await this.adapter.setScore(kind, userId, score);
        }
        catch (error) {
            logger.warn('leaderboard_set_failed', { kind, userId, message: error instanceof Error ? error.message : 'failed' });
        }
    }
    async safeIncrement(kind, userId, amount) {
        try {
            await this.adapter.increment(kind, userId, amount);
        }
        catch (error) {
            logger.warn('leaderboard_increment_failed', { kind, userId, message: error instanceof Error ? error.message : 'failed' });
        }
    }
    async deriveRows(kind, limit) {
        if (kind === 'winnings')
            return repositories.transactions.listWinnings(limit);
        const users = await repositories.users.list(1000);
        return users
            .filter((user) => !user.id.startsWith('bot_'))
            .map((user) => ({ userId: user.id, score: kind === 'weekly' ? Number(user.weeklyScore ?? 0) : Number(user.xp ?? 0) }))
            .filter((row) => row.score > 0)
            .sort((a, b) => b.score - a.score || a.userId.localeCompare(b.userId))
            .slice(0, limit);
    }
    async enrich(kind, rows, viewerUserId) {
        const entries = [];
        const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
        for (const row of rows) {
            const uid = String(row.userId);
            if (!UUID_RE.test(uid))
                continue; // defensively skip any corrupt id — never 500 the board
            let user = null;
            try {
                user = await repositories.users.findById(uid);
            }
            catch {
                user = null;
            }
            const rank = entries.length + 1;
            entries.push({
                rank,
                userId: uid,
                username: user?.username ?? uid,
                displayName: user?.displayName ?? user?.username ?? uid,
                avatar: avatarFor(rank - 1, uid),
                level: user?.level ?? 1,
                score: Math.round(Number(row.score ?? 0)),
                metric: kind,
                highlighted: viewerUserId === uid
            });
        }
        return entries;
    }
}
function clampLimit(limit) {
    if (!Number.isFinite(limit))
        return 50;
    return Math.min(100, Math.max(1, Math.floor(limit)));
}
function titleFor(kind) {
    if (kind === 'weekly')
        return 'Weekly XP League';
    if (kind === 'overall')
        return 'Overall XP';
    return 'Highest Winnings';
}
function metricLabelFor(kind) {
    if (kind === 'weekly')
        return 'weeklyScore';
    if (kind === 'overall')
        return 'xp';
    return 'winnings';
}
function avatarFor(index, userId) {
    const avatars = ['🦁', '🦊', '🐼', '🐯', '👾', '🐙', '🦄', '🐲'];
    let hash = index;
    for (const ch of userId)
        hash += ch.charCodeAt(0);
    return avatars[Math.abs(hash) % avatars.length];
}
const adapter = process.env.LEADERBOARD_ADAPTER === 'redis' && process.env.REDIS_URL
    ? new RedisLeaderboardAdapter()
    : new MemoryLeaderboardAdapter();
export const leaderboards = new LeaderboardService(adapter);
