function tier(cfg, color) {
    return cfg.economy.tickets[color] || { value: 0, units: 0 };
}
export function ticketValue(cfg, color) {
    return Math.max(0, Math.round(tier(cfg, color).value));
}
export function ticketUnits(cfg, color) {
    return Math.max(0, Math.round(tier(cfg, color).units));
}
/** Gross pot (sum of ticket values), the house rake, and the net pot players split. */
export function buildPool(cfg, colors) {
    const gross = colors.reduce((s, c) => s + ticketValue(cfg, c), 0);
    const rakePercent = Math.max(0, Math.min(100, Number(cfg.economy.rakePercent) || 0));
    const rake = Math.round((gross * rakePercent) / 100);
    return { gross, rake, net: gross - rake };
}
/** Sum of units of players still in the running (alive). */
export function activeUnits(players) {
    return players.filter((p) => p.status === 'alive').reduce((s, p) => s + Math.max(0, p.units), 0);
}
/**
 * A single player's current cash-out share of the remaining pot. Floored to an
 * integer toman (the house keeps sub-toman dust; final split reconciles the
 * remainder so nothing is lost).
 */
export function currentShare(remainingPot, myUnits, aliveUnits) {
    if (aliveUnits <= 0 || myUnits <= 0 || remainingPot <= 0)
        return 0;
    return Math.floor((remainingPot * myUnits) / aliveUnits);
}
/** Cash-out share for a specific alive player given the current field. */
export function cashoutShareFor(player, players, remainingPot) {
    if (player.status !== 'alive')
        return 0;
    return currentShare(remainingPot, Math.max(0, player.units), activeUnits(players));
}
/**
 * Final split when the match ends: distribute the ENTIRE remaining pot among the
 * still-alive players by units. Any integer remainder (from flooring) goes to the
 * player with the most units (ties → first), so sum(payouts) === remainingPot.
 * Returns a map userId → payout.
 */
export function finalSplit(players, remainingPot) {
    const alive = players.filter((p) => p.status === 'alive' && p.units > 0);
    const out = {};
    const totalUnits = alive.reduce((s, p) => s + p.units, 0);
    if (remainingPot <= 0 || totalUnits <= 0 || alive.length === 0) {
        for (const p of alive)
            out[p.userId] = 0;
        return out;
    }
    let distributed = 0;
    for (const p of alive) {
        const share = Math.floor((remainingPot * p.units) / totalUnits);
        out[p.userId] = share;
        distributed += share;
    }
    const remainder = remainingPot - distributed;
    if (remainder > 0) {
        // Give the dust to the largest stake (deterministic, tie → first listed).
        const top = alive.slice().sort((a, b) => b.units - a.units || (a.userId < b.userId ? -1 : 1))[0];
        if (top)
            out[top.userId] = (out[top.userId] ?? 0) + remainder;
    }
    return out;
}
export function computeStats(players, grossPot) {
    const paidOut = players.filter((p) => p.status === 'cashed_out').reduce((s, p) => s + (p.payoutCash || 0), 0);
    return {
        totalPlayers: players.length,
        alive: players.filter((p) => p.status === 'alive').length,
        eliminated: players.filter((p) => p.status === 'eliminated').length,
        cashedOut: players.filter((p) => p.status === 'cashed_out').length,
        grossPot,
        paidOut,
        remainingPot: Math.max(0, grossPot - paidOut),
        activeUnits: activeUnits(players)
    };
}
