import { repositories } from '../repositories/index.js';
import { calculateUserRisk, listCurrentUserDevices } from './deviceRiskService.js';
export async function searchAdminUsers(query = '', limit = 100) {
    const users = await repositories.users.list(Math.min(1000, Math.max(1, limit)));
    const q = query.trim().toLowerCase();
    const filtered = q
        ? users.filter((u) => [u.id, u.phone, u.username, u.displayName].some((value) => String(value ?? '').toLowerCase().includes(q)))
        : users;
    const rows = [];
    for (const user of filtered.slice(0, limit)) {
        const risk = await repositories.devices.getRiskProfile(user.id).catch(() => null);
        rows.push(toListItem(user, risk ?? undefined));
    }
    return rows;
}
export async function getAdminUserOverview(userId) {
    const user = await repositories.users.findById(userId);
    if (!user)
        return null;
    const [transactions, devices, riskProfile, tickets, integritySignals, rewardHolds] = await Promise.all([
        repositories.transactions.listByUser(userId),
        listCurrentUserDevices(userId).catch(() => []),
        calculateUserRisk(userId).catch(() => null),
        repositories.support.listTickets({ userId, limit: 20 }).catch(() => []),
        repositories.integrity.list({ userId, limit: 20 }).catch(() => []),
        repositories.rewardHolds.list({ userId, limit: 20 }).catch(() => [])
    ]);
    return {
        user: toListItem(user, riskProfile ?? undefined),
        balances: { wallet: user.wallet, coins: user.coins, hearts: user.hearts, tickets: user.tickets },
        transactions: transactions.slice(0, 20),
        devices,
        riskProfile,
        tickets,
        integritySignals,
        rewardHolds
    };
}
export async function updateUserStatus(userId, status, reason) {
    const user = await repositories.users.findById(userId);
    if (!user)
        return null;
    user.status = status;
    user.banReason = status === 'banned' || status === 'limited' ? reason : undefined;
    user.bannedAt = status === 'banned' ? new Date().toISOString() : undefined;
    await repositories.users.save(user);
    const risk = await repositories.devices.getRiskProfile(userId).catch(() => null);
    return toListItem(user, risk ?? undefined);
}
/* Edit core profile/progression fields directly (admin override). Wallet is NOT
 * edited here — money only moves through the ledger (/admin/wallet/adjust). */
export async function updateUserFields(userId, fields) {
    const user = await repositories.users.findById(userId);
    if (!user)
        return null;
    if (typeof fields.displayName === 'string' && fields.displayName.trim())
        user.displayName = fields.displayName.trim();
    if (typeof fields.username === 'string' && fields.username.trim())
        user.username = fields.username.trim();
    if (Number.isFinite(fields.xp))
        user.xp = Math.max(0, Math.round(fields.xp));
    if (Number.isFinite(fields.level))
        user.level = Math.max(1, Math.round(fields.level));
    if (Number.isFinite(fields.weeklyScore))
        user.weeklyScore = Math.max(0, Math.round(fields.weeklyScore));
    if (Number.isFinite(fields.coins))
        user.coins = Math.max(0, Math.round(fields.coins));
    if (Number.isFinite(fields.hearts))
        user.hearts = Math.max(0, Math.round(fields.hearts));
    await repositories.users.save(user);
    const risk = await repositories.devices.getRiskProfile(userId).catch(() => null);
    return toListItem(user, risk ?? undefined);
}
/* Set (or add to) a user's ticket count for a tier — a granted asset, not a
 * wallet movement. mode 'set' overwrites, 'add' increments. */
export async function setUserTickets(userId, tier, count, mode) {
    const user = await repositories.users.findById(userId);
    if (!user)
        return null;
    // Go through the atomic ticket update — users.save does NOT persist the
    // tickets JSONB column, so writing it there silently loses the grant.
    const { grantTickets, setTickets } = await import('./ticketService.js');
    return mode === 'add' ? grantTickets(userId, tier, count) : setTickets(userId, tier, count);
}
/* Reset progression stats (xp/level/weekly cup) — does NOT touch the wallet. */
export async function resetUserStats(userId) {
    const user = await repositories.users.findById(userId);
    if (!user)
        return null;
    user.xp = 0;
    user.level = 1;
    user.weeklyScore = 0;
    await repositories.users.save(user);
    const risk = await repositories.devices.getRiskProfile(userId).catch(() => null);
    return toListItem(user, risk ?? undefined);
}
export async function updateUserRole(userId, role) {
    const user = await repositories.users.findById(userId);
    if (!user)
        return null;
    user.role = role;
    await repositories.users.save(user);
    const risk = await repositories.devices.getRiskProfile(userId).catch(() => null);
    return toListItem(user, risk ?? undefined);
}
function toListItem(user, risk) {
    return {
        id: user.id,
        phone: user.phone,
        username: user.username,
        displayName: user.displayName,
        plan: user.plan,
        role: user.role ?? 'user',
        status: user.status ?? 'active',
        level: user.level,
        xp: user.xp,
        weeklyScore: user.weeklyScore,
        wallet: user.wallet,
        coins: user.coins,
        hearts: user.hearts,
        riskScore: risk?.riskScore,
        riskLevel: risk?.riskLevel
    };
}
