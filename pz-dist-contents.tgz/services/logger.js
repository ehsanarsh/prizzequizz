const levelOrder = { debug: 10, info: 20, warn: 30, error: 40 };
const configuredLevel = process.env.LOG_LEVEL ?? (process.env.NODE_ENV === 'production' ? 'info' : 'debug');
export const logger = {
    debug(message, context = {}) { write('debug', message, context); },
    info(message, context = {}) { write('info', message, context); },
    warn(message, context = {}) { write('warn', message, context); },
    error(message, context = {}) { write('error', message, context); }
};
function write(level, message, context) {
    if (levelOrder[level] < levelOrder[configuredLevel])
        return;
    const record = {
        ts: new Date().toISOString(),
        level,
        service: 'prizzequizz-api',
        message,
        ...context
    };
    const line = JSON.stringify(record);
    if (level === 'error')
        console.error(line);
    else if (level === 'warn')
        console.warn(line);
    else
        console.log(line);
}
