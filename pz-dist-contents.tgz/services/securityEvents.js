import { db } from '../repositories/memory.js';
import { id } from '../utils/id.js';
import { logger } from './logger.js';
export function recordSecurityEvent(input) {
    const event = {
        id: id(),
        userId: input.userId,
        eventType: input.eventType,
        severity: input.severity ?? 'info',
        ipAddress: input.req?.socket.remoteAddress,
        userAgent: input.req?.headers['user-agent'],
        metadata: input.metadata ?? {},
        createdAt: new Date().toISOString()
    };
    db.securityEvents.set(event.id, event);
    logger.warn('security_event', event);
}
