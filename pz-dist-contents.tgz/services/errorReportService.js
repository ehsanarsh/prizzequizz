import { repositories } from '../repositories/index.js';
import { id } from '../utils/id.js';
import { logger } from './logger.js';
export async function createErrorReport(input) {
    const report = {
        id: id(),
        userId: input.userId,
        source: input.source ?? 'frontend',
        severity: input.severity ?? 'error',
        status: 'open',
        message: input.message.slice(0, 1000),
        stack: input.stack?.slice(0, 8000),
        route: input.route?.slice(0, 1000),
        userAgent: input.userAgent?.slice(0, 1000),
        appVersion: input.appVersion?.slice(0, 80),
        buildId: input.buildId?.slice(0, 120),
        deviceId: input.deviceId?.slice(0, 120),
        metadata: input.metadata ?? {},
        createdAt: new Date().toISOString()
    };
    await repositories.errorReports.save(report);
    logger.warn('error_report_created', { id: report.id, source: report.source, severity: report.severity, message: report.message });
    return report;
}
export async function listErrorReports(filter = {}) {
    return repositories.errorReports.list(filter);
}
export async function updateErrorReportStatus(id, status, resolvedBy) {
    return repositories.errorReports.updateStatus(id, status, resolvedBy);
}
export async function errorReportDiagnostics() {
    const reports = await repositories.errorReports.list({ limit: 500 });
    const since = Date.now() - 24 * 60 * 60 * 1000;
    return {
        open: reports.filter((r) => r.status === 'open').length,
        triaged: reports.filter((r) => r.status === 'triaged').length,
        resolved: reports.filter((r) => r.status === 'resolved').length,
        ignored: reports.filter((r) => r.status === 'ignored').length,
        fatal: reports.filter((r) => r.severity === 'fatal').length,
        frontend: reports.filter((r) => r.source === 'frontend').length,
        backend: reports.filter((r) => r.source === 'backend').length,
        last24h: reports.filter((r) => new Date(r.createdAt).getTime() >= since).length,
        topMessages: topMessages(reports)
    };
}
function topMessages(reports) {
    const counts = new Map();
    for (const report of reports) {
        const key = report.message.slice(0, 120);
        counts.set(key, (counts.get(key) ?? 0) + 1);
    }
    return [...counts.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8).map(([message, count]) => ({ message, count }));
}
