import { getPgPool } from '../database/postgres.js';
/* Every table worth keeping. Anything missing in a given deployment is skipped
 * rather than failing the whole backup. */
export const BACKUP_TABLES = [
    'users', 'questions', 'matches', 'match_players', 'answers',
    'wallet_accounts', 'wallet_ledger', 'withdraw_requests', 'transactions',
    'company_expenses', 'shop_items', 'shop_purchases',
    'ls_rooms', 'ls_room_players', 'ls_answers', 'ls_config',
    'admin_accounts', 'app_config', 'ticket_promos', 'user_avatars',
    'friendships', 'friend_messages', 'support_tickets', 'support_messages',
    'notifications', 'notification_preferences', 'scheduled_notifications',
    'question_answer_stats', 'reward_holds', 'integrity_signals', 'security_events',
    'devices', 'user_device_bindings', 'user_risk_profiles',
    'payment_intents', 'monitor_servers', 'gift_codes', 'beta_invites', 'beta_access'
];
/** Rows read per round-trip. Small enough that one page is never a memory event. */
const PAGE = 2_000;
/** Hard cap per table, so one runaway log table can't make the file unusable. */
const MAX_ROWS_PER_TABLE = 200_000;
/** Wait for the socket to drain before queueing more, or a slow client turns a
 *  streaming export straight back into an in-memory one. */
function write(res, chunk) {
    if (res.write(chunk))
        return Promise.resolve();
    return new Promise((resolve) => res.once('drain', resolve));
}
/**
 * Streams the whole dump into `res`. `meta` is written LAST — the totals are
 * only known once every table has been read, and key order is irrelevant to a
 * JSON parser.
 */
export async function streamBackup(res) {
    const generatedAt = new Date().toISOString();
    const skipped = [];
    let rows = 0;
    let tables = 0;
    let pool = null;
    try {
        pool = process.env.DATABASE_URL ? getPgPool() : null;
    }
    catch {
        pool = null;
    }
    await write(res, '{"data":{');
    if (pool) {
        let firstTable = true;
        for (const table of [...new Set(BACKUP_TABLES)]) {
            let opened = false;
            try {
                for (let offset = 0; offset < MAX_ROWS_PER_TABLE; offset += PAGE) {
                    // Identifier is from our own constant list, never from user input.
                    // Ordered by ctid so paging is stable without assuming a sort column.
                    const r = await pool.query(`SELECT * FROM ${table} ORDER BY ctid LIMIT ${PAGE} OFFSET ${offset}`);
                    if (!opened) {
                        // Opened only after the first query succeeds, so a missing table
                        // leaves no half-written key behind.
                        await write(res, `${firstTable ? '' : ','}${JSON.stringify(table)}:[`);
                        firstTable = false;
                        opened = true;
                        tables += 1;
                    }
                    for (let i = 0; i < r.rows.length; i++) {
                        await write(res, (offset === 0 && i === 0 ? '' : ',') + JSON.stringify(r.rows[i]));
                    }
                    rows += r.rows.length;
                    if (r.rows.length < PAGE)
                        break; // last page
                }
                if (opened)
                    await write(res, ']');
            }
            catch {
                if (opened)
                    await write(res, ']'); // keep the document well-formed
                else
                    skipped.push(table);
            }
        }
    }
    else {
        skipped.push('no-database');
    }
    const meta = { generatedAt, app: 'prizzequizz', tables, rows, skipped };
    await write(res, `},"meta":${JSON.stringify(meta)}}`);
    return { tables, rows, skipped };
}
/** Filename the browser should save it under. */
export function backupFilename() {
    const d = new Date();
    const p = (n) => String(n).padStart(2, '0');
    return `prizzequizz-backup-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}.json`;
}
