export class MemoryMatchStateStore {
    store = new Map();
    async get(matchId) {
        const row = this.store.get(matchId);
        if (!row)
            return null;
        if (row.expiresAt && row.expiresAt < Date.now()) {
            this.store.delete(matchId);
            return null;
        }
        return row.match;
    }
    async set(match, ttlSeconds) {
        this.store.set(match.id, { match, expiresAt: ttlSeconds ? Date.now() + ttlSeconds * 1000 : undefined });
    }
    async delete(matchId) {
        this.store.delete(matchId);
    }
    async list() {
        const now = Date.now();
        const out = [];
        for (const [id, row] of this.store) {
            if (row.expiresAt && row.expiresAt < now) {
                this.store.delete(id);
                continue;
            }
            out.push(row.match);
        }
        return out.sort((a, b) => String(b.updatedAt ?? '').localeCompare(String(a.updatedAt ?? '')));
    }
}
export const activeMatchState = new MemoryMatchStateStore();
