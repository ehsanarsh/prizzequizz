import webPush from 'web-push';
import { repositories } from '../repositories/index.js';
import { id } from '../utils/id.js';
import { logger } from './logger.js';
class LogPushProvider {
    name = 'log';
    async send(subscription, payload) {
        logger.info('push_notification_logged', { userId: subscription.userId, endpointHash: hashEndpoint(subscription.endpoint), title: payload.title });
    }
}
class WebPushProvider {
    name = 'webpush';
    constructor() {
        webPush.setVapidDetails(process.env.VAPID_SUBJECT || 'mailto:admin@prizzequizz.local', process.env.VAPID_PUBLIC_KEY || '', process.env.VAPID_PRIVATE_KEY || '');
    }
    async send(subscription, payload) {
        await webPush.sendNotification({ endpoint: subscription.endpoint, keys: { p256dh: subscription.p256dh, auth: subscription.auth } }, JSON.stringify(payload));
    }
}
export class NotificationService {
    provider;
    constructor(provider) {
        this.provider = provider;
    }
    async subscribe(userId, input, userAgent) {
        if (!input.endpoint || !input.keys?.p256dh || !input.keys?.auth)
            throw new Error('INVALID_PUSH_SUBSCRIPTION');
        const now = new Date().toISOString();
        const record = {
            id: id(),
            userId,
            endpoint: input.endpoint,
            p256dh: input.keys.p256dh,
            auth: input.keys.auth,
            deviceLabel: input.deviceLabel,
            userAgent,
            createdAt: now,
            updatedAt: now,
            lastSeenAt: now
        };
        await repositories.notifications.saveSubscription(record);
        await this.create({ userId, type: 'system', title: 'اعلان‌ها فعال شد', body: 'از این به بعد پیام‌های مهم PrizzeQuizz را دریافت می‌کنی.', push: false });
        return record;
    }
    async revoke(subscriptionId, userId) {
        return repositories.notifications.revokeSubscription(subscriptionId, userId);
    }
    async preferences(userId) {
        const existing = await repositories.notifications.getPreferences(userId);
        if (existing)
            return existing;
        const defaults = defaultPreferences(userId);
        await repositories.notifications.savePreferences(defaults);
        return defaults;
    }
    async updatePreferences(userId, patch) {
        const current = await this.preferences(userId);
        const next = {
            ...current,
            matchUpdates: patch.matchUpdates ?? current.matchUpdates,
            leaderboardUpdates: patch.leaderboardUpdates ?? current.leaderboardUpdates,
            walletUpdates: patch.walletUpdates ?? current.walletUpdates,
            promos: patch.promos ?? current.promos,
            quietHoursStart: typeof patch.quietHoursStart === 'string' ? patch.quietHoursStart : current.quietHoursStart,
            quietHoursEnd: typeof patch.quietHoursEnd === 'string' ? patch.quietHoursEnd : current.quietHoursEnd,
            updatedAt: new Date().toISOString()
        };
        await repositories.notifications.savePreferences(next);
        return next;
    }
    async list(userId, limit = 50) {
        return repositories.notifications.listNotifications(userId, Math.min(100, Math.max(1, limit)));
    }
    async markRead(notificationId, userId) {
        return repositories.notifications.markRead(notificationId, userId);
    }
    async markAllRead(userId) {
        return repositories.notifications.markAllRead(userId);
    }
    async create(input) {
        const notification = {
            id: id(),
            userId: input.userId,
            type: input.type,
            title: input.title.slice(0, 160),
            body: input.body.slice(0, 800),
            data: input.data ?? {},
            channel: input.push ? 'push' : 'in_app',
            status: 'queued',
            createdAt: new Date().toISOString()
        };
        await repositories.notifications.saveNotification(notification);
        if (input.push !== false)
            await this.dispatch(notification);
        return notification;
    }
    async broadcast(input) {
        let created = 0;
        let sent = 0;
        let skipped = 0;
        for (const userId of input.userIds) {
            const allowed = await this.allowedByPreference(userId, input.type);
            if (!allowed) {
                skipped += 1;
                continue;
            }
            const notification = await this.create({ userId, type: input.type, title: input.title, body: input.body, data: input.data, push: input.push });
            created += 1;
            if (notification.status === 'sent')
                sent += 1;
        }
        return { created, sent, skipped };
    }
    async diagnostics() {
        const users = await repositories.users.list(1000);
        let subscriptions = 0;
        let queued = 0;
        let sent = 0;
        let failed = 0;
        let unread = 0;
        for (const user of users) {
            subscriptions += (await repositories.notifications.listSubscriptions(user.id)).length;
            const rows = await repositories.notifications.listNotifications(user.id, 1000);
            queued += rows.filter((n) => n.status === 'queued').length;
            sent += rows.filter((n) => n.status === 'sent').length;
            failed += rows.filter((n) => n.status === 'failed').length;
            unread += rows.filter((n) => !n.readAt).length;
        }
        return { provider: this.provider.name, vapidConfigured: vapidConfigured(), subscriptions, queued, sent, failed, unread };
    }
    async dispatch(notification) {
        if (!(await this.allowedByPreference(notification.userId, notification.type))) {
            notification.status = 'queued';
            await repositories.notifications.saveNotification(notification);
            return;
        }
        const subscriptions = await repositories.notifications.listSubscriptions(notification.userId);
        if (!subscriptions.length) {
            notification.status = 'queued';
            await repositories.notifications.saveNotification(notification);
            return;
        }
        const payload = { id: notification.id, type: notification.type, title: notification.title, body: notification.body, data: notification.data, url: notification.data.url ?? '/' };
        try {
            await Promise.all(subscriptions.map((sub) => this.provider.send(sub, payload)));
            notification.status = 'sent';
            notification.sentAt = new Date().toISOString();
        }
        catch (error) {
            notification.status = 'failed';
            notification.error = error instanceof Error ? error.message : 'push failed';
            logger.warn('push_notification_failed', { notificationId: notification.id, userId: notification.userId, message: notification.error });
        }
        await repositories.notifications.saveNotification(notification);
    }
    async allowedByPreference(userId, type) {
        const prefs = await this.preferences(userId);
        if (inQuietHours(prefs))
            return false;
        if (type === 'match_update')
            return prefs.matchUpdates;
        if (type === 'leaderboard_update')
            return prefs.leaderboardUpdates;
        if (type === 'wallet_update')
            return prefs.walletUpdates;
        if (type === 'promo')
            return prefs.promos;
        return true;
    }
}
function defaultPreferences(userId) {
    return { userId, matchUpdates: true, leaderboardUpdates: true, walletUpdates: true, promos: false, updatedAt: new Date().toISOString() };
}
function inQuietHours(prefs) {
    if (!prefs.quietHoursStart || !prefs.quietHoursEnd)
        return false;
    const now = new Date();
    const current = now.getHours() * 60 + now.getMinutes();
    const start = parseTime(prefs.quietHoursStart);
    const end = parseTime(prefs.quietHoursEnd);
    if (start === null || end === null || start === end)
        return false;
    return start < end ? current >= start && current < end : current >= start || current < end;
}
function parseTime(value) {
    const match = /^(\d{2}):(\d{2})$/.exec(value);
    if (!match)
        return null;
    const h = Number(match[1]);
    const m = Number(match[2]);
    if (h < 0 || h > 23 || m < 0 || m > 59)
        return null;
    return h * 60 + m;
}
function vapidConfigured() {
    return Boolean(process.env.VAPID_PUBLIC_KEY && process.env.VAPID_PRIVATE_KEY);
}
function hashEndpoint(endpoint) {
    let hash = 0;
    for (const ch of endpoint)
        hash = ((hash << 5) - hash + ch.charCodeAt(0)) | 0;
    return Math.abs(hash).toString(16);
}
const provider = process.env.PUSH_PROVIDER === 'webpush' && vapidConfigured()
    ? new WebPushProvider()
    : new LogPushProvider();
export const notifications = new NotificationService(provider);
