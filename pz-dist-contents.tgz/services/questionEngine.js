import { repositories } from '../repositories/index.js';
let cursor = 0;
export async function nextQuestion() {
    const questions = await repositories.questions.listApproved();
    if (!questions.length)
        throw new Error('NO_QUESTIONS');
    const q = questions[cursor % questions.length];
    cursor += 1;
    return q;
}
export async function validateAnswer(questionId, selectedIndex) {
    const q = await repositories.questions.findById(questionId);
    if (!q)
        throw new Error('QUESTION_NOT_FOUND');
    return { correct: selectedIndex === q.correctIndex, correctIndex: q.correctIndex };
}
