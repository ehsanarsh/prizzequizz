/* AUDIENCE SEGMENTS for notifications.
 * Resolves a compound segment spec (all criteria AND-ed) into the matching user
 * IDs, using REAL user data: plan, status, level, XP, wallet, tickets, signup
 * date, and last-seen (from game_sessions). Compound = several criteria at once
 * (e.g. paid AND level>=5 AND inactive 7d). Postgres-backed with a memory
 * fallback for the dev driver.
 *
 * HONEST LIMITS: "city" and "app version" segments are NOT offered — the app
 * stores neither, so we don't fake them. Everything here is backed by columns
 * that actually exist. */
import { getPgPool } from '../database/postgres.js';
import { repositories } from '../repositories/index.js';
function pg() {
    try {
        return process.env.DATABASE_URL ? getPgPool() : null;
    }
    catch {
        return null;
    }
}
function num(v) { const n = Number(v); return Number.isFinite(n) ? n : undefined; }
// Human-readable one-line description of a segment, for the admin history/UI.
export function describeSegment(s) {
    if (s.userIds && s.userIds.length && !hasCriteria(s))
        return `${s.userIds.length} کاربر دستی`;
    const p = [];
    const base = { all: 'همه', online: 'آنلاین', offline: 'آفلاین', new: 'کاربران جدید', inactive: 'غیرفعال' };
    if (s.base && base[s.base])
        p.push(base[s.base]);
    if (s.plan)
        p.push(s.plan === 'paid' ? 'اشتراک پولی' : 'رایگان');
    if (s.status && s.status !== 'any')
        p.push({ active: 'فعال', limited: 'محدود', banned: 'مسدود' }[s.status]);
    if (s.minLevel != null)
        p.push(`سطح ≥ ${s.minLevel}`);
    if (s.maxLevel != null)
        p.push(`سطح ≤ ${s.maxLevel}`);
    if (s.minXp != null)
        p.push(`XP ≥ ${s.minXp}`);
    if (s.maxXp != null)
        p.push(`XP ≤ ${s.maxXp}`);
    if (s.walletGt != null)
        p.push(`موجودی > ${s.walletGt}`);
    if (s.walletLt != null)
        p.push(`موجودی < ${s.walletLt}`);
    if (s.hasTickets === true)
        p.push('دارای بلیط');
    if (s.hasTickets === false)
        p.push('بدون بلیط');
    if (s.newWithinDays != null)
        p.push(`عضو ${s.newWithinDays} روز اخیر`);
    if (s.inactiveDays != null)
        p.push(`${s.inactiveDays} روز غیرفعال`);
    if (s.userIds && s.userIds.length)
        p.push(`+ ${s.userIds.length} دستی`);
    return p.length ? p.join(' · ') : 'همه کاربران';
}
function hasCriteria(s) {
    return Boolean(s.base && s.base !== 'all') || s.plan != null || (s.status && s.status !== 'any') ||
        s.minLevel != null || s.maxLevel != null || s.minXp != null || s.maxXp != null ||
        s.walletLt != null || s.walletGt != null || s.hasTickets != null ||
        s.newWithinDays != null || s.inactiveDays != null || s.onlineMinutes != null;
}
// Normalize base presets into concrete numeric criteria.
function normalize(s) {
    const n = { ...s };
    if (n.base === 'online' && n.onlineMinutes == null)
        n.onlineMinutes = 5;
    if (n.base === 'new' && n.newWithinDays == null)
        n.newWithinDays = 7;
    if (n.base === 'inactive' && n.inactiveDays == null)
        n.inactiveDays = 7;
    return n;
}
/* A hand-typed recipient is whatever the operator entered — an id, a username,
 * or a phone number. It used to be passed straight through, so anything that
 * was not already a real user id reached an insert against a UUID column and
 * killed the whole send with "invalid input syntax for type uuid". Resolving it
 * here means the panel can accept any of the three and a typo simply drops out
 * of the audience instead of failing the campaign. */
export async function resolveRecipients(raw) {
    const ids = [];
    const unknown = [];
    for (const entry of [...new Set(raw.map((x) => String(x || '').trim()).filter(Boolean))]) {
        let user = await repositories.users.findById(entry).catch(() => null);
        if (!user)
            user = await repositories.users.findByPhone(entry).catch(() => null);
        if (!user) {
            const all = await repositories.users.list(100000).catch(() => []);
            user = all.find((u) => u.username === entry) ?? null;
        }
        if (user)
            ids.push(user.id);
        else
            unknown.push(entry);
    }
    return { ids, unknown };
}
export async function resolveSegment(spec, cap = 100000) {
    const s = normalize(spec || {});
    const typed = Array.isArray(s.userIds) ? s.userIds.map(String).filter(Boolean) : [];
    const resolved = typed.length ? await resolveRecipients(typed) : { ids: [], unknown: [] };
    const manual = resolved.ids;
    // Pure manual list (no other criteria) → those people, and only real ones.
    if (typed.length && !hasCriteria(s) && s.base !== 'offline') {
        return { userIds: manual.slice(0, cap), count: manual.length, unknown: resolved.unknown };
    }
    const pool = pg();
    if (pool) {
        const where = [];
        const args = [];
        const add = (cond, val) => { if (val !== undefined) {
            args.push(val);
            where.push(cond.replace('$?', `$${args.length}`));
        }
        else {
            where.push(cond);
        } };
        // Default: exclude banned unless explicitly targeting a status.
        if (s.status && s.status !== 'any')
            add('u.status = $?', s.status);
        else
            where.push(`coalesce(u.status,'active') <> 'banned'`);
        if (s.plan)
            add('u.plan = $?', s.plan);
        if (num(s.minLevel) != null)
            add('u.level >= $?', num(s.minLevel));
        if (num(s.maxLevel) != null)
            add('u.level <= $?', num(s.maxLevel));
        if (num(s.minXp) != null)
            add('u.xp >= $?', num(s.minXp));
        if (num(s.maxXp) != null)
            add('u.xp <= $?', num(s.maxXp));
        if (num(s.walletGt) != null)
            add('u.wallet_balance > $?', num(s.walletGt));
        if (num(s.walletLt) != null)
            add('u.wallet_balance < $?', num(s.walletLt));
        if (s.hasTickets === true)
            where.push(`(coalesce((u.tickets->>'bronze')::int,0)+coalesce((u.tickets->>'silver')::int,0)+coalesce((u.tickets->>'gold')::int,0)) > 0`);
        if (s.hasTickets === false)
            where.push(`(coalesce((u.tickets->>'bronze')::int,0)+coalesce((u.tickets->>'silver')::int,0)+coalesce((u.tickets->>'gold')::int,0)) = 0`);
        if (num(s.newWithinDays) != null)
            add(`u.created_at >= now() - ($? || ' days')::interval`, String(num(s.newWithinDays)));
        // Session-based criteria need the latest last_seen per user.
        const needSession = num(s.onlineMinutes) != null || num(s.inactiveDays) != null || s.base === 'offline';
        if (num(s.onlineMinutes) != null)
            add(`s.ls >= now() - ($? || ' minutes')::interval`, String(num(s.onlineMinutes)));
        if (num(s.inactiveDays) != null)
            add(`(s.ls IS NULL OR s.ls < now() - ($? || ' days')::interval)`, String(num(s.inactiveDays)));
        if (s.base === 'offline')
            where.push(`(s.ls IS NULL OR s.ls < now() - interval '5 minutes')`);
        const join = needSession ? `LEFT JOIN (SELECT user_id, max(last_seen_at) ls FROM game_sessions GROUP BY user_id) s ON s.user_id = u.id` : '';
        const sql = `SELECT u.id FROM users u ${join} ${where.length ? 'WHERE ' + where.join(' AND ') : ''} ORDER BY u.updated_at DESC LIMIT ${cap}`;
        let ids = [];
        try {
            const { rows } = await pool.query(sql, args);
            ids = rows.map((r) => r.id);
        }
        catch {
            ids = (await repositories.users.list(cap)).map((u) => u.id);
        } // safety net
        // Union manual ids (compound "these criteria OR these specific people").
        if (manual.length)
            ids = [...new Set([...ids, ...manual])];
        return { userIds: ids.slice(0, cap), count: ids.length, unknown: resolved.unknown };
    }
    // ---- Memory fallback (dev driver: no sessions, best-effort on user fields) ----
    let users = await repositories.users.list(cap);
    if (!(s.status && s.status === 'any'))
        users = users.filter((u) => (u.status ?? 'active') !== 'banned' || s.status === 'banned');
    if (s.status && s.status !== 'any')
        users = users.filter((u) => (u.status ?? 'active') === s.status);
    if (s.plan)
        users = users.filter((u) => u.plan === s.plan);
    if (num(s.minLevel) != null)
        users = users.filter((u) => u.level >= num(s.minLevel));
    if (num(s.maxLevel) != null)
        users = users.filter((u) => u.level <= num(s.maxLevel));
    if (num(s.minXp) != null)
        users = users.filter((u) => u.xp >= num(s.minXp));
    if (num(s.maxXp) != null)
        users = users.filter((u) => u.xp <= num(s.maxXp));
    if (num(s.walletGt) != null)
        users = users.filter((u) => u.wallet > num(s.walletGt));
    if (num(s.walletLt) != null)
        users = users.filter((u) => u.wallet < num(s.walletLt));
    if (s.hasTickets === true)
        users = users.filter((u) => (u.tickets.bronze + u.tickets.silver + u.tickets.gold) > 0);
    if (s.hasTickets === false)
        users = users.filter((u) => (u.tickets.bronze + u.tickets.silver + u.tickets.gold) === 0);
    let ids = users.map((u) => u.id);
    if (manual.length)
        ids = [...new Set([...ids, ...manual])];
    return { userIds: ids.slice(0, cap), count: ids.length, unknown: resolved.unknown };
}
